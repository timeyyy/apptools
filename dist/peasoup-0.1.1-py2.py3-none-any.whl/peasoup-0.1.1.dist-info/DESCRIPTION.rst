This is a project to increase development speed of gui and cli projects


