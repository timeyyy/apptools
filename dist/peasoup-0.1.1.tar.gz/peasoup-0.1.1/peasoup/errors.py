'''

    peasoup.errors : Exceptions for the peasoup package

'''

class ConnectionError(Exception):
    pass

